# frozen_string_literal: true

module Jekyll
  VERSION = "3.6.2".freeze
end

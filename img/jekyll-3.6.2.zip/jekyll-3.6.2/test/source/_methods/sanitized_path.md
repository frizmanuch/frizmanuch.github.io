---
title: "Jekyll.sanitized_path"
---

`{{ page.title }}` is used to make sure your path is in your source.
